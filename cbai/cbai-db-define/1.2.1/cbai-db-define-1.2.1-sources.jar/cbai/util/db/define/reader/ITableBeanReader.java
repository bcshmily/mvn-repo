package cbai.util.db.define.reader;

import java.util.List;

import cbai.util.db.define.TableBean;

public interface ITableBeanReader {
    List<TableBean> readTableList();
}

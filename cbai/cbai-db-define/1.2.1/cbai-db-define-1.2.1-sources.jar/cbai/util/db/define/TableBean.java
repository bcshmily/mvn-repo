package cbai.util.db.define;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class TableBean implements Serializable {
    private static final long serialVersionUID = 1L;

    public enum TABLE_TYPE {
        TABLE, VIEW
    }

    private TABLE_TYPE tableType = TABLE_TYPE.TABLE;

    /**
     * schema
     */
    private String schema;

    /**
     * 来源
     */
    private String sourceName;

    /**
     * 表物理名
     */
    private String tableName;
    /**
     * 表伦理名
     */
    private String tableFullName;

    /**
     * 表中的字段列表
     */
    private List<FieldBean> fieldList;

    /**
     * 其它项目
     */
    private Map<String, String> others = null;

    /**
     * 表中的字段
     */
    private transient Map<String, FieldBean> fieldMap;

    /**
     * tableTypeを取得する。
     *
     * @return tableType
     */
    public TABLE_TYPE getTableType() {
        return tableType;
    }

    /**
     * tableTypeを設定する。
     *
     * @param tableType tableType
     */
    public void setTableType(TABLE_TYPE tableType) {
        this.tableType = tableType;
    }

    /**
     * 来源を取得する。
     *
     * @return 来源
     */
    public String getSourceName() {
        return sourceName;
    }

    /**
     * 来源を設定する。
     *
     * @param sourceName 来源
     */
    public void setSourceName(String sourceName) {
        this.sourceName = sourceName;
    }

    /**
     * 表物理名を取得する。
     *
     * @return 表物理名
     */
    public String getTableName() {
        return tableName;
    }

    /**
     * 表物理名を設定する。
     *
     * @param tableName 表物理名
     */
    /**
     * tableNameを設定する。
     *
     * @param tableName tableName
     */
    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    /**
     * 表伦理名を取得する。
     *
     * @return 表伦理名
     */
    public String getTableFullName() {
        return tableFullName;
    }

    /**
     * 表伦理名を設定する。
     *
     * @param tableFullName 表伦理名
     */
    public void setTableFullName(String tableFullName) {
        this.tableFullName = tableFullName;
    }

    /**
     * 表中的字段列表を取得する。
     *
     * @return 表中的字段列表
     */
    public List<FieldBean> getFieldList() {
        return fieldList;
    }

    /**
     * 表中的字段列表を設定する。
     *
     * @param fieldList 表中的字段列表
     */
    public void setFieldList(List<FieldBean> fieldList) {
        this.fieldList = fieldList;
    }

    public Map<String, String> getOthers() {
        return others;
    }

    public void setOthers(Map<String, String> others) {
        this.others = others;
    }

    /**
     * 表中的字段を取得する。
     *
     * @return 表中的字段
     */
    public Map<String, FieldBean> getFieldMap() {
        if (fieldMap == null) {
            fieldMap = new LinkedHashMap<String, FieldBean>();
            for (FieldBean bean : fieldList) {
                fieldMap.put(bean.getFieldFullName(), bean);
            }
        }
        return fieldMap;
    }

    /**
     * 表中的字段を設定する。
     *
     * @param fieldMap 表中的字段
     */
    public void setFieldMap(Map<String, FieldBean> fieldList) {
        this.fieldMap = fieldList;
    }

    public String getSchema() {
        return schema;
    }

    public void setSchema(String schema) {
        this.schema = schema;
    }

    public List<String> createPkColumns() {
        List<String> pkColumns = new ArrayList<String>();
        for (FieldBean bean : fieldList) {
            if (bean.isKey()) {
                pkColumns.add(bean.getFieldName());
            }
        }
        return pkColumns;
    }

    public String createDeleteSql() {
        return "DELETE FROM " + this.getTableName();
    }

    public String createSelectSql() {
        StringBuilder sb = new StringBuilder();
        List<String> pkColumns = new ArrayList<String>();
        sb.append("SELECT ");
        for (int i = 0; i < this.fieldList.size(); i++) {
            FieldBean fb = this.fieldList.get(i);
            if (i != 0) {
                sb.append(",");
            }
            sb.append(fb.getFieldName());
            if (fb.isKey()) {
                pkColumns.add(fb.getFieldName());
            }
        }
        sb.append(" FROM ").append(this.getTableName());
        if (!pkColumns.isEmpty()) {
            sb.append(" ORDER BY ");
            for (int i = 0; i < pkColumns.size(); i++) {
                if (i != 0) {
                    sb.append(",");
                }
                sb.append((String) pkColumns.get(i));
            }
        }
        return sb.toString();
    }

    public String createInsertSql() {
        StringBuilder insertSql = new StringBuilder();
        insertSql.append("INSERT INTO ").append(this.getTableName()).append(" (");
        StringBuilder values = new StringBuilder();
        int fieldCount = this.fieldList.size();
        for (int index = 0; index < fieldCount; index++) {
            FieldBean columnDefinition = this.fieldList.get(index);
            insertSql.append(columnDefinition.getFieldName());
            values.append("?");
            if (index + 1 != fieldCount) {
                insertSql.append(",");
                values.append(",");
            }
        }
        insertSql.append(") VALUES (").append(values).append(")");
        return insertSql.toString();
    }

    @Override
    public String toString() {
        return "TableBean [tableType=" + tableType + ", schema=" + schema + ", sourceName=" + sourceName + ", tableName=" + tableName
                + ", tableFullName=" + tableFullName + ", fieldList=" + fieldList + ", others=" + others + "]";
    }

}

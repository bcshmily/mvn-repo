package cbai.util.db.define.type;

public class ColumnType {
	private JavaColumnType javaType;
	private JdbcColumnType jdbcType;

	public ColumnType(JavaColumnType javaType, JdbcColumnType jdbcType) {
		this.javaType = javaType;
		this.jdbcType = jdbcType;
	}

	public JavaColumnType getJavaType() {
		return javaType;
	}

	public void setJavaType(JavaColumnType javaType) {
		this.javaType = javaType;
	}

	public JdbcColumnType getJdbcType() {
		return jdbcType;
	}

	public void setJdbcType(JdbcColumnType jdbcType) {
		this.jdbcType = jdbcType;
	}

}
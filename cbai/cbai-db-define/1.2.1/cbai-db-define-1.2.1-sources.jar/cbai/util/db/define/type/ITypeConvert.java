package cbai.util.db.define.type;

public interface ITypeConvert {

	ColumnType convert(String fieldType);
}

package cbai.util.db.define;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class TableBean implements Serializable {
    private static final long serialVersionUID = 1L;

    /**
     * 表类型：TABLE 或 VIEW
     */
    public enum TABLE_TYPE {
        TABLE, VIEW
    }

    private TABLE_TYPE tableType = TABLE_TYPE.TABLE;

    /**
     * schema
     */
    private String schema;

    /**
     * 来源
     */
    private String sourceName;

    /**
     * 表物理名
     */
    private String tableName;
    /**
     * 表伦理名
     */
    private String tableFullName;

    /**
     * 表中的字段列表
     */
    private List<FieldBean> fieldList;

    /**
     * 其它项目（可选键值对，用于扩展元数据）
     */
    private Map<String, String> others = null;

    /**
     * tableTypeを取得する。
     *
     * @return tableType
     */
    public TABLE_TYPE getTableType() {
        return tableType;
    }

    /**
     * tableTypeを設定する。
     *
     * @param tableType tableType
     */
    public void setTableType(TABLE_TYPE tableType) {
        this.tableType = tableType;
    }

    /**
     * 来源を取得する。
     *
     * @return 来源
     */
    public String getSourceName() {
        return sourceName;
    }

    /**
     * 来源を設定する。
     *
     * @param sourceName 来源
     */
    public void setSourceName(String sourceName) {
        this.sourceName = sourceName;
    }

    /**
     * 表物理名を取得する。
     *
     * @return 表物理名
     */
    public String getTableName() {
        return tableName;
    }

    /**
     * 表物理名を設定する。
     *
     * @param tableName 表物理名
     */
    /**
     * tableNameを設定する。
     *
     * @param tableName tableName
     */
    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    /**
     * 表伦理名を取得する。
     *
     * @return 表伦理名
     */
    public String getTableFullName() {
        return tableFullName;
    }

    /**
     * 表伦理名を設定する。
     *
     * @param tableFullName 表伦理名
     */
    public void setTableFullName(String tableFullName) {
        this.tableFullName = tableFullName;
    }

    /**
     * 表中的字段列表を取得する。
     *
     * @return 表中的字段列表
     */
    public List<FieldBean> getFieldList() {
        return fieldList;
    }

    /**
     * 表中的字段列表を設定する。
     *
     * @param fieldList 表中的字段列表
     */
    public void setFieldList(List<FieldBean> fieldList) {
        this.fieldList = fieldList;
    }

    /**
     * 获取其它扩展信息的键值映射。
     * <p>
     * 用于存放表的额外元数据（可为空）。
     *
     * @return 其它信息的映射，可能为 null
     */
    public Map<String, String> getOthers() {
        return others;
    }

    /**
     * 设置其它扩展信息的键值映射。
     *
     * @param others 其它信息的映射，可以为 null
     */
    public void setOthers(Map<String, String> others) {
        this.others = others;
    }

    /**
     * 表中的字段を取得する。
     *
     * @return 表中的字段
     */
    public static Map<String, FieldBean> getFieldMap(TableBean tableBean) {
        if (tableBean != null) {
            Map<String, FieldBean> fieldMap = new LinkedHashMap<String, FieldBean>();
            for (FieldBean bean : tableBean.getFieldList()) {
                fieldMap.put(bean.getFieldFullName(), bean);
            }
            return fieldMap;
        }
        return null;
    }

    /**
     * 获取 schema 名称。
     *
     * @return schema 名称，可能为 null
     */
    public String getSchema() {
        return schema;
    }

    /**
     * 设置 schema 名称。
     *
     * @param schema schema 名称
     */
    public void setSchema(String schema) {
        this.schema = schema;
    }

    /**
     * 创建主键列名称的列表（按字段声明顺序）。
     *
     * @return 主键列名列表（如果没有主键，则为空列表）
     */
    public List<String> createPkColumns() {
        List<String> pkColumns = new ArrayList<String>();
        for (FieldBean bean : fieldList) {
            if (bean.isKey()) {
                pkColumns.add(bean.getFieldName());
            }
        }
        return pkColumns;
    }

    /**
     * 生成删除整表的 SQL（无 WHERE 子句）。
     *
     * @return DELETE SQL，例如 "DELETE FROM tableName"
     */
    public String createDeleteSql() {
        return "DELETE FROM " + this.getTableName();
    }

    /**
     * 生成按表字段列表的 SELECT SQL，若表中存在主键则追加 ORDER BY 主键列。
     *
     * @return SELECT SQL
     */
    public String createSelectSql() {
        StringBuilder sb = new StringBuilder();
        List<String> pkColumns = new ArrayList<String>();
        sb.append("SELECT ");
        for (int i = 0; i < this.fieldList.size(); i++) {
            FieldBean fb = this.fieldList.get(i);
            if (i != 0) {
                sb.append(",");
            }
            sb.append(fb.getFieldName());
            if (fb.isKey()) {
                pkColumns.add(fb.getFieldName());
            }
        }
        sb.append(" FROM ").append(this.getTableName());
        if (!pkColumns.isEmpty()) {
            sb.append(" ORDER BY ");
            for (int i = 0; i < pkColumns.size(); i++) {
                if (i != 0) {
                    sb.append(",");
                }
                sb.append((String) pkColumns.get(i));
            }
        }
        return sb.toString();
    }

    /**
     * 生成 INSERT SQL，使用问号占位符与字段顺序一致。
     *
     * @return INSERT SQL，例如 "INSERT INTO tableName (col1,col2) VALUES (?,?)"
     */
    public String createInsertSql() {
        StringBuilder insertSql = new StringBuilder();
        insertSql.append("INSERT INTO ").append(this.getTableName()).append(" (");
        StringBuilder values = new StringBuilder();
        int fieldCount = this.fieldList.size();
        for (int index = 0; index < fieldCount; index++) {
            FieldBean columnDefinition = this.fieldList.get(index);
            insertSql.append(columnDefinition.getFieldName());
            values.append("?");
            if (index + 1 != fieldCount) {
                insertSql.append(",");
                values.append(",");
            }
        }
        insertSql.append(") VALUES (").append(values).append(")");
        return insertSql.toString();
    }

    @Override
    public String toString() {
        return "TableBean [tableType=" + tableType + ", schema=" + schema + ", sourceName=" + sourceName + ", tableName=" + tableName
                + ", tableFullName=" + tableFullName + ", fieldList=" + fieldList + ", others=" + others + "]";
    }

}
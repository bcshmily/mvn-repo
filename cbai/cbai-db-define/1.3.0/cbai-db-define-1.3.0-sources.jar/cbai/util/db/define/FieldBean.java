package cbai.util.db.define;

import java.io.Serializable;
import java.util.Map;

/**
 * 表字段的元数据类（FieldBean）。
 *
 * <p>保存单个字段的常用属性：是否为主键、是否允许空、物理名/伦理名、类型、长度、备注，以及可选的扩展键值对。</p>
 */
public class FieldBean implements Serializable {
    private static final long serialVersionUID = 1L;

    /**
     * 是否是主键
     */
    private boolean key = false;

    /** 非空 */
    private boolean notNull = false;

    /**
     * 字段物理名
     */
    private String fieldName;

    /**
     * 字段伦理名
     */
    private String fieldFullName;

    /**
     * 字段类型
     */
    private String type;

    /**
     * 字段长度
     */
    private String len;

    /**
     * 字段小数长度
     */
    private String dotLen;

    /**
     * 字段备注
     */
    private String comment;

    /**
     * 其它项目
     */
    private Map<String, String> others = null;

    /**
     * 返回字段的扩展属性映射（可用于存放自定义元数据）。
     *
     * @return 扩展属性映射，若无则可能返回 null
     */
    public Map<String, String> getOthers() {
        return others;
    }

    /**
     * 设置字段的扩展属性映射。
     *
     * @param others 扩展属性映射，可以为 null
     */
    public void setOthers(Map<String, String> others) {
        this.others = others;
    }

    /**
     * 返回字段的备注说明。
     *
     * @return 字段备注，可能为 null
     */
    public String getComment() {
        return comment;
    }

    /**
     * 设置字段备注。
     *
     * @param comment 备注内容，可以为 null
     */
    public void setComment(String comment) {
        this.comment = comment;
    }

    /**
     * 是否是主键を取得します。
     *
     * @return 是否是主键
     */
    public boolean isKey() {
        return key;
    }

    /**
     * 是否是主键を設定します。
     *
     * @param key
     *            是否是主键
     */
    public void setKey(boolean key) {
        this.key = key;
    }

    /**
     * 非空を取得する。
     *
     * @return 非空
     */
    public boolean isNotNull() {
        return notNull;
    }

    /**
     * 非空を設定する。
     *
     * @param notNull
     *            非空
     */
    public void setNotNull(boolean notNull) {
        this.notNull = notNull;
    }

    /**
     * 字段物理名を取得します。
     *
     * @return 字段物理名
     */
    public String getFieldName() {
        return fieldName;
    }

    /**
     * 字段物理名を設定します。
     *
     * @param fieldName
     *            字段物理名
     */
    public void setFieldName(String fieldName) {
        this.fieldName = fieldName;
    }

    /**
     * 字段伦理名を取得します。
     *
     * @return 字段伦理名
     */
    public String getFieldFullName() {
        return fieldFullName;
    }

    /**
     * 字段伦理名を設定します。
     *
     * @param fieldFullName
     *            字段伦理名
     */
    public void setFieldFullName(String fieldFullName) {
        this.fieldFullName = fieldFullName;
    }

    /**
     * 字段类型を取得します。
     *
     * @return 字段类型
     */
    public String getType() {
        return type;
    }

    /**
     * 字段类型を設定します。
     *
     * @param type
     *            字段类型
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * 字段长度を取得します。
     *
     * @return 字段长度
     */
    public String getLen() {
        return len;
    }

    /**
     * 字段长度を設定します。
     *
     * @param len
     *            字段长度
     */
    public void setLen(String len) {
        this.len = len;
    }

    /**
     * 字段小数长度を取得します。
     *
     * @return 字段小数长度
     */
    public String getDotLen() {
        return dotLen;
    }

    /**
     * 字段小数长度を設定します。
     *
     * @param dotLen
     *            字段小数长度
     */
    public void setDotLen(String dotLen) {
        this.dotLen = dotLen;
    }

    @Override
    public String toString() {
        return "FieldBean [key=" + key + ", notNull=" + notNull + ", fieldName=" + fieldName + ", fieldFullName=" + fieldFullName + ", type=" + type
                + ", len=" + len + ", dotLen=" + dotLen + ", comment=" + comment + ", others=" + others + "]";
    }
}